__author__ = 'Luke'

import reader
from matching_solution import MatchingSolution
import hillclimbing
import time

"""
def experiment_one(name_array, instances):

Performs experiment one on a list of populations.
@param      name_array [str]    - an array of strings representing base file names ie AUS_10_190_0
@param      instances (int)     - the amount of populations with each base file name

Returns a 3D array of the results of each run.
"""
def experiment_one(name_array, instances, output=False, paces=1):
    results_array = []
    for name in name_array:
        this_names_row = []
        for n in range(0, instances):
            print(name + "_i" + (str)(n))
            this_populations_row = [0]*5
            pop_txt = name + "_i" + (str)(n) + ".txt"
            pop_csv = name + "_i" + (str)(n) + ".csv"
            sol_csv = name + "_i" + (str)(n) + "_results.csv"
            initialSolution = reader.create_from_parts(pop_csv, pop_txt, sol_csv)

            time1 = time.clock()
            bestSolution = hillclimbing.hill_climbing(initialSolution, 10000, output, paces)
            time2 = time.clock()
            this_populations_row[0] = (str)(time2 - time1)
            this_populations_row[1] = initialSolution.weight
            this_populations_row[2] = bestSolution.weight
            this_populations_row[3] = initialSolution.solution
            this_populations_row[4] = bestSolution.solution

            this_names_row.append(this_populations_row)
        results_array.append(this_names_row)
    return results_array

def experiment_this():
    pop_txt = "AUS_10_190_0_i0.txt"
    pop_csv = "AUS_10_190_0_i0.csv"
    sol_csv = "AUS_10_190_0_i0_results.csv"
    for paces in [3, 5, 10]:
        for x in range(0, 5):
            print("Paces = " + (str)(paces))
            print("x = " + (str) (x))
            initialSolution = reader.create_from_parts(pop_csv, pop_txt, sol_csv)
            time1 = time.clock()
            bestSolution = hillclimbing.hill_climbing(initialSolution, 10000, False, paces)
            time2 = time.clock()
            print("Time Taken: " + (str) (time2-time1))




"""
def write_experiment_to_txt(results_array, filename):

Writes a 3D experiment results array to a txt file for later use.

@param      results_array [][][]    - a 3D experiment results array
@param      filename (str)          - the name of the file to append to
@param      name_array [str]        - an array of the base file names used
"""
def write_experiment_to_txt(results_array, filename, name_array):
    filename += ".csv"
    myFile = open(filename, 'a')
    name = 0
    for this_names_row in results_array:
        i = 0
        for this_populations_row in this_names_row:
            print("Starting " + name_array[name] + "_i" + (str)(i) + "\n")
            my_string = name_array[name] + "_i" + (str)(i) + "\n"
            myFile.write(my_string)
            my_string = "Time Taken," + (str) (this_populations_row[0]) + "\n"
            myFile.write(my_string)
            my_string = "Initial Solution," + (str) (this_populations_row[1]) + "\n"
            myFile.write(my_string)
            my_string = "Best Solution," + (str) (this_populations_row[2]) + "\n"
            myFile.write(my_string)
            i += 1
        name += 1

def write_bat_file(filename, name_array, instances):
    myFile = open(filename, 'w')
    for name in name_array:
        for i in range(0, instances):
            # Example line java -jar kidneyMatching125.jar -mode deterministicMode -kepIn input/AUS_10_190_0/AUS_10_190_0_i3.csv -optPackingOut output/AUS_10_190_0/AUS_10_190_0_i3_results.csv
            line = "java -jar kidneyMatching125.jar -mode deterministicMode -kepIn input/"
            line += (str) (name)
            line += "/"
            line += (str) (name)
            line += "_i"
            line += (str) (i)
            line += ".csv -optPackingOut output/"
            line += (str) (name)
            line += "/"
            line += (str) (name)
            line += "_i"
            line += (str) (i)
            line += "_results.csv\n"
            myFile.write(line)



if __name__ == "__main__":
    #name_array = ["AUS_10_190_0"]
    #results_array = experiment_one(name_array, 1, True, 2)

    experiment_this()


    #name_array=["AUS_10_190_0", "AUS_0_200_0"]
    #print("Experimenting")
    #results_array = experiment_one(name_array, 30)
    #print("Writing")
    #write_experiment_to_txt(results_array, "first_set_of_results", name_array)
    #write_bat_file("test_bat_file", ["AUS_0_200_0", "AUS_5_195_0"], 30)




