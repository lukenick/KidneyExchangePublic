__author__ = 'Luke'
"""
Kidney Exchange Clinical Generators
Methods related to population generation in the Kidney Exchange Problem using quasi-clinical data
@since      8/11/2014
@modified   18/06/2015
@author     Luke Nickholds
"""
import random
import math
import printer

"""
def clinical_generate_blood_types1(NbNodes, freq):
Generates a 1D array of blood types that conform to given specifications (default from Australian Red Cross)

@param      NbNodes (int)   - the number of nodes to generate a bloodtype for
@param      freq [int]      - an array containing in order the frequencies of O+, O-, A+, A-, B+, B-, AB+, AB- (Default = AUST)
@complexity O(N) where N is the size of NbNodes
"""
def clinical_generate_blood_types1(NbNodes,freq=[40, 9, 31, 7, 8, 2, 2, 1]):
    BloodType = [0]*NbNodes
    for i in range(0, NbNodes):
        value = math.ceil(random.random()*100)
        if value <= sum(freq[0:1]):
            BloodType[i] = "O+"
        elif value <= sum(freq[0:2]):
            BloodType[i] = "O-"
        elif value <= sum(freq[0:3]):
            BloodType[i] = "A+"
        elif value <= sum(freq[0:4]):
            BloodType[i] = "A-"
        elif value <= sum(freq[0:5]):
            BloodType[i] = "B+"
        elif value <= sum(freq[0:6]):
            BloodType[i] = "B-"
        elif value <= sum(freq[0:7]):
            BloodType[i] = "AB+"
        else:
            BloodType[i] = "AB-"
    return BloodType
#Test function for clinical_generate_blood_types
def test_clinical_generate_blood_types1():
    print("4 Random Blood Types as per specifications")
    print(clinical_generate_blood_types1(4))
    print("\n 20 Random Blood Types as per specifications")
    print(clinical_generate_blood_types1(20))


"""
def compatible_blood_type(donor_type, patient_type):
Checks if donor_type can give blood to patient_type
Blood types are using ABO and Rhesus groups

@param      donor_type (str) - the blood type of the donor, a string representation such as "AB+" or "O-"
@param      patient_type (str) - the blood type of the donor, a string representation such as "AB+" or "O-"
@complexity O(1)
"""
def compatible_blood_type(donor_type, patient_type):
    donor_array = ["O-", "O+", "B-", "B+", "A-", "A+", "AB-", "AB+"]
    patient_array = ["AB+", "AB-", "A+", "A-", "B+", "B-", "O+", "O-"]
    compatability_array = [0]*8
    compatability_array[0] = [ True,  True,  True,  True,  True,  True,  True,  True]
    compatability_array[1] = [ True, False,  True, False,  True, False,  True, False]
    compatability_array[2] = [ True,  True, False, False,  True,  True, False, False]
    compatability_array[3] = [ True, False, False, False,  True, False, False, False]
    compatability_array[4] = [ True,  True,  True,  True, False, False, False, False]
    compatability_array[5] = [ True, False,  True, False, False, False, False, False]
    compatability_array[6] = [ True,  True, False, False, False, False, False, False]
    compatability_array[7] = [ True, False, False, False, False, False, False, False]
    for i in range(0, 8):
        if donor_type == donor_array[i]:
           donor_cell = i
        if patient_type == patient_array[i]:
            patient_cell = i
    return compatability_array[patient_cell][donor_cell]
# Test Function for compatible_blood_type
def test_compatible_blood_type():
    print("\nTesting Compatibility of Blood Types")
    types = ["O-", "O+", "B-", "B+", "A-", "A+", "AB-", "AB+"]
    for donor in types:
        print()
        for patient in types:
            if compatible_blood_type(donor, patient):
                print("A donor of type " + donor + " can give to a patient of type " + patient)
            else:
                print("A donor of type " + donor + " cannot give to a patient of type " + patient)


"""
def clinical_generate_graph1(NbNodes):
Generates a 2D array of size NbNodes by NbNodes that simulates a population under the given specs (Aust)
This assumes that each donor-patient pair has the same bloodtype, but is otherwise incompatible. All weights 1 or 0
It only takes ABO blood type into consideration, not PRA/HLA.

@param      NbNodes (int)   - the number of vertices on the graph
@complexity O(N^2) where N is the size of NbNodes
"""
def clinical_generate_graph1(NbNodes):
    ArcCosts = [[-9999 for i in range(NbNodes)] for i in range(NbNodes)] # Create blank array of -9999
    BloodType = clinical_generate_blood_types1(NbNodes)
    for i in range(0, NbNodes):
        for j in range(0, NbNodes):
            if (compatible_blood_type(BloodType[i], BloodType[j])) and i!=j:
                ArcCosts[i][j] = 1
    return ArcCosts
# Test function for clinical_generate_graph1
def test_clinical_generate_graph1():
    print("\nTesting clinical_generate_graph1")
    graph1 = clinical_generate_graph1(5)
    print("\nGraph using Clinical Data of size 5")
    printer.print_matrix(graph1)

    graph2 = clinical_generate_graph1(20)
    print("\nGraph using Clinical Data of size 20")
    printer.print_matrix(graph2)


"""
def clinical_generate_graph2(NbNodes):
Generates a 2D array of size NbNodes by NbNodes that simulates a population under the given specs (Aust)
This assumes that patient-donor pairs have separate blood types and can trade if their types match and their HLA does too

@param      NbNodes (int)   - the number of vertices on the graph
@complexity O(N^2) where N is the size of NbNodes
"""
def clinical_generate_graph2(NbNodes):
    ArcCosts = [[-9999 for i in range(NbNodes)] for i in range(NbNodes)] # Create blank array of -9999
    DonorType = clinical_generate_blood_types1(NbNodes)                  # ABO blood type of the donor in a pair (A, B, O, AB)
    PatientType = clinical_generate_blood_types1(NbNodes)                # ABO blood type of the patient in a pair
    PatientPRA = [ (random.random() *100) for i in range(NbNodes)]      # PRA of the patient in a pair (0 to 100)

    for i in range(0,NbNodes):
        for j in range(0, NbNodes):
            if (compatible_blood_type(DonorType[i], PatientType[j])): # need to add "and i!=j" if pairs cant match with self
                if (PatientPRA[j] < 10) & (random.random() > 0.05):     # Low PRA patients
                    ArcCosts[i][j] = 1
                elif (PatientPRA[j] < 80) & (random.random() > 0.45):   # Medium PRA patients
                    ArcCosts[i][j] = 1
                elif (random.random() > 0.9):                          # High PRA patients
                    ArcCosts[i][j] = 1
    return ArcCosts
# Test function for clinical_generate_graph2
def test_clinical_generate_graph2():
    print("\nTesting clinical_generate_graph2")
    graph1 = clinical_generate_graph2(5)
    print("\nGraph using Clinical Data of size 5")
    printer.print_matrix(graph1)

    graph2 = clinical_generate_graph2(20)
    print("\nGraph using Clinical Data of size 20")
    printer.print_matrix(graph2)


"""
def compatible_PRA1(PRA)
Models PRA using three discrete categories of Low, Medium and High

@param      PRA (int) - an integer between 0 and 100 representing the patients PRA
@complexity O(1)
"""

def compatible_PRA1(PRA):
    if (PRA < 10) & (random.random() > 0.05):     # Low PRA patients
        return True
    elif (PRA < 80) & (random.random() > 0.45):   # Medium PRA patients
        return True
    elif (random.random() > 0.9):                 # High PRA patients
        return True
    else:
        return False

if __name__ == "__main__":
    test_clinical_generate_blood_types1()
    #test_compatible_blood_type()
    #test_clinical_generate_graph1()
    #test_clinical_generate_graph2()