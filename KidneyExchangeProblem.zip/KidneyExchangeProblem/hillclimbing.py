__author__ = 'Luke'
"""
Kidney Exchange Hill Climbing
@since      27/05/2015
@modified   27/05/2015
@author     Luke Nickholds
Method for implementing hill climbing
"""

from matching_solution import MatchingSolution
import simple_swapper

#These imports are used in the testing functions
import printer
import population_library
import random, math

"""
Previously, the method known as random_ascent was called hill_climbing. This has been left in for legacy purposes whilst
checking through for code that needs the updated name
"""
def hill_climbing(initial_solution, iterations, output=False, paces=1):
    return random_ascent(initial_solution, iterations, output, paces)


"""
def random_ascent(initial_solution, iterations, output=False):

Implements the hill-climbing algorithm using a RANDOM ascent, using smarter_swap to generate new solutions.
@param      initial_solution (MatchingSolution)     - an initial, feasible solution
@param      iterations (int)                        - the number of new solutions to generate
@param      output (bool)                           - set to True to print both weights each iteration. Default=False
@param      paces (int)                             - how many times to run smarter_swap to generate new sol. Default=1
@complexity O(MN) where N is the amount of iterations, and O(N) is the complexity of smarter_swap
"""
def random_ascent(initial_solution, iterations, output=False, paces=1):
    best_solution = initial_solution
    best_i = -1     # Keep track of which iteration last had a switch occur
    for i in range(iterations):
        new_solution = best_solution
        for _ in range(paces):
            new_solution = simple_swapper.smarter_swap(new_solution)
        if (output):
            print("Iteration: " + (str)(i))
            print("New Solution Weight = " + (str) (new_solution.weight))
            print("Best Solution Weight = " + (str) (best_solution.weight))
        if (new_solution.weight > best_solution.weight):
            best_solution = new_solution
            best_i = i
    if True: #output:      # If output, display at the end when the last iteration with a switch was
        print("Best Solution Weight = " + (str) (best_solution.weight))
        print("Best Solution was found during iteration " + (str) (best_i))
    return best_solution
# Test Function for hill_climbing
def test_hill_climbing1():
    comp = population_library.basic_graph02
    edges = [[math.floor(random.random()*10) for i in range(len(comp[0]))] for i in range(len(comp))]
    initial_solution = MatchingSolution(comp, edges, [["Cycle", 0, 4, 1], ["Cycle", 2, 6, 3]])
    best_solution = hill_climbing(initial_solution, 200, True)

# If iterations =-1, keep going till done
"""
def steepest_ascent(initial_solution, iterations=-1, output=False):

Implements the hill-climbing algorithm using a STEEPEST ascent, using best_swap to generate new solutions.
@param      initial_solution (MatchingSolution)     - an initial, feasible solution
@param      iterations (int)                        - function stops after this many iterations, or when there is no improvement. Default= -1 : keep going till stuck
@param      output (bool)                           - set to True to print the new best Solution each iteration. Default=False
"""
def steepest_ascent(initial_solution, iterations=-1, output=False):
    current_solution = initial_solution
    new_solution = simple_swapper.best_swap(current_solution)
    i = 0
    while (i != iterations) and (current_solution.solution != new_solution.solution):
        i += 1
        current_solution = new_solution
        new_solution = simple_swapper.best_swap(current_solution)
        if output:
            print("Iteration: " + (str) (i))
            print("New Solution Weight: " + (str) (new_solution.weight))
    return new_solution



if __name__ == "__main__":
    test_hill_climbing1()