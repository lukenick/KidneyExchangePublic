__author__ = 'Luke'
"""
Kidney Exchange Altruistic Generators
Methods related to population generation in the Kidney Exchange Problem using quasi-clinical data
Populations generated contain Altruists, Pairs and Terminals
@since      8/11/2014
@modified   18/06/2015
@author     Luke Nickholds

Modules to generate sample
"""
import random
import math
import printer
import clinicalgenerator

"""
def altruistic_generate_graph1(NbAltruists, NbPairs, NbTerminal):
Generates a 2D array that simulates a population
The first rows will be the Altrustic Donors who will only be able to donate
The middle rows will be the pair donors
The last rows will be the terminal donors who will only be able to receive

@param      NbAltruists (int) - the number of altruist donors on the graph
@param      NbPairs (int)     - the number of donor PAIRS on the graph
@param      NbTerminal (int)  - the number of terminal donors on the graph
@param      MaxArcCost (int)  - the maximum weight of valid arcs.   Default=100
@param      compatible (bool) - boolean indicating whether compatible pairs should be included in the graph
@complexity O(N^2) where N is the sum of NbPairs, NbAltruists and NbTerminal
"""
def altruistic_generate_graph1(NbAltruists, NbPairs, NbTerminal, compatible=False, MaxArcCost=100, ):
    total = NbAltruists + NbPairs + NbTerminal

    ArcCosts = [[-9999 for i in range(total)] for i in range(total)]

    AltruistType = clinicalgenerator.clinical_generate_blood_types1(NbAltruists)    # ABO+ Blood Type
    PairedDonorType = clinicalgenerator.clinical_generate_blood_types1(NbPairs)     # Default freq = AUST
    PairedPatientType = clinicalgenerator.clinical_generate_blood_types1(NbPairs)
    TerminalType = clinicalgenerator.clinical_generate_blood_types1(NbTerminal)

    PairedPatientPRA = [ (random.random() * 100) for i in range(NbPairs)]       # PRA is only relevant for recipients
    TerminalPRA = [ (random.random() * 100) for i in range(NbTerminal)]         # PRA = 0 to 100

    for i in range(0, NbAltruists):                                      # Filling in the rows of altruist donors
        for j in range(total):
            if (j < NbAltruists):               # Altruists donating to Altruists
                pass
            elif (j < (NbAltruists + NbPairs)): # Altruists donating to Pairs
                if ( clinicalgenerator.compatible_blood_type( AltruistType[i], PairedPatientType[j - NbAltruists]) ):
                    if ( clinicalgenerator.compatible_PRA1(PairedPatientPRA[j- NbAltruists]) ):
                        ArcCosts[i][j] = (int) (1 + math.floor(random.random()*(MaxArcCost))) # All arcs between 1 and MaxArcCost
            else:                               # Altruists donating to Terminals
                 if ( clinicalgenerator.compatible_blood_type( AltruistType[i], TerminalType[j - NbAltruists - NbPairs] ) ):
                    if ( clinicalgenerator.compatible_PRA1(TerminalPRA[j - NbAltruists - NbPairs]) ):
                        ArcCosts[i][j] = (int) (1 + math.floor(random.random()*(MaxArcCost))) # All arcs between 1 and MaxArcCost

    for i in range(NbAltruists, (NbAltruists + NbPairs)):               # Filling in the rows of paired donors
        for j in range(total):
            if (j < NbAltruists):               # Pairs donating to Altruists
                pass
            elif (j < (NbAltruists + NbPairs)): # Pairs donating to Pairs
                if ( clinicalgenerator.compatible_blood_type(( PairedDonorType[i - NbAltruists]), PairedPatientType[j - NbAltruists]) ):
                    if ( clinicalgenerator.compatible_PRA1(PairedPatientPRA[j - NbAltruists]) ):
                        ArcCosts[i][j] = (int) (1 + math.floor(random.random()*(MaxArcCost))) # All arcs between 1 and MaxArcCost
            else:                               # Pairs donating to Terminals
                if ( clinicalgenerator.compatible_blood_type( PairedDonorType[i - NbAltruists], TerminalType[j - NbAltruists - NbPairs] ) ):
                    if ( clinicalgenerator.compatible_PRA1(TerminalPRA[j - NbAltruists - NbPairs]) ):
                        ArcCosts[i][j] = (int) (1 + math.floor(random.random()*(MaxArcCost))) # All arcs between 1 and MaxArcCost

    # No need to iterate through the terminal donors row, as terminal donors are unable to donate to anyone

    # This check whether we want to include non-compatible donors or not
    if not compatible:
        for i in range(total):
            ArcCosts[i][i] = -9999



    return ArcCosts
# Test function for altruistic_generate_graph2
def test_altruistic_generate_graph1():
    print("Reminder that each row represents who they can donate to")
    print("\nTesting altruistic_generate_graph1 with 2 Altruists, 5 Pairs, 3 Terminals")
    graph1 = altruistic_generate_graph1(2, 5, 3)
    printer.print_matrix(graph1)

"""
def altruistic_generate_graph2(NbAltruists, NbPairs):
Generates a 2D array that simulates a population. There will be one terminal per altruist.
The first rows will be the Altrustic Donors who will only be able to donate
The middle rows will be the pair donors
The last rows will be the terminal donors who will only be able to receive

@param      NbAltruists (int) - the number of altruist donors on the graph
@param      NbPairs (int)     - the number of donor PAIRS on the graph
@param      MaxArcCost (int)  - the maximum weight of valid arcs.   Default=100
@param      compatible (bool) - boolean indicating whether compatible pairs should be included in the graph
@complexity O(N^2) where N is the sum of NbPairs, NbAltruists and NbTerminal
"""
def altruistic_generate_graph2(NbAltruists, NbPairs, compatible=False, MaxArcCost=100, ):
    NbTerminal = NbAltruists
    total = NbAltruists + NbPairs + NbTerminal

    ArcCosts = [[-9999 for i in range(total)] for i in range(total)]

    AltruistType = clinicalgenerator.clinical_generate_blood_types1(NbAltruists)    # ABO+ Blood Type
    PairedDonorType = clinicalgenerator.clinical_generate_blood_types1(NbPairs)     # Default freq = AUST
    PairedPatientType = clinicalgenerator.clinical_generate_blood_types1(NbPairs)
    TerminalType = clinicalgenerator.clinical_generate_blood_types1(NbTerminal)

    PairedPatientPRA = [ (random.random() * 100) for i in range(NbPairs)]       # PRA is only relevant for recipients
    TerminalPRA = [ (random.random() * 100) for i in range(NbTerminal)]         # PRA = 0 to 100

    for i in range(0, NbAltruists):                                      # Filling in the rows of altruist donors
        for j in range(total):
            if (j < NbAltruists):               # Altruists donating to Altruists
                pass
            elif (j < (NbAltruists + NbPairs)): # Altruists donating to Pairs
                if ( clinicalgenerator.compatible_blood_type( AltruistType[i], PairedPatientType[j - NbAltruists]) ):
                    if ( clinicalgenerator.compatible_PRA1(PairedPatientPRA[j- NbAltruists]) ):
                        ArcCosts[i][j] = (int) (1 + math.floor(random.random()*(MaxArcCost))) # All arcs between 1 and MaxArcCost
            else:                               # Altruists donating to Terminals
                 ArcCosts[i][j] = 1             # Dummy terminals can receive any donation

    for i in range(NbAltruists, (NbAltruists + NbPairs)):               # Filling in the rows of paired donors
        for j in range(total):
            if (j < NbAltruists):               # Pairs donating to Altruists
                pass
            elif (j < (NbAltruists + NbPairs)): # Pairs donating to Pairs
                if ( clinicalgenerator.compatible_blood_type(( PairedDonorType[i - NbAltruists]), PairedPatientType[j - NbAltruists]) ):
                    if ( clinicalgenerator.compatible_PRA1(PairedPatientPRA[j - NbAltruists]) ):
                        ArcCosts[i][j] = (int) (1 + math.floor(random.random()*(MaxArcCost))) # All arcs between 1 and MaxArcCost
            else:                               # Pairs donating to Terminals
                ArcCosts[i][j] = 1              # Dummy terminals can receive any donation

    # No need to iterate through the terminal donors row, as terminal donors are unable to donate to anyone

    # This check whether we want to include non-compatible donors or not
    if not compatible:
        for i in range(total):
            ArcCosts[i][i] = -9999



    return ArcCosts

def test_altruistic_generate_graph2():
    print("Reminder that each row represents who they can donate to")
    print("\nTesting altruistic_generate_graph1 with 3 Altruists, 5 Pairs, 3 Dummy Terminals")
    graph1 = altruistic_generate_graph2(3, 10)
    printer.print_matrix(graph1)


if __name__ == "__main__":
    test_altruistic_generate_graph2()
