__author__ = 'Luke'

"""
def find(my_list, item):

Returns the position of a given item in a list. If the item is not found, returns False.
@param      my_list []      - the list to search in
@param      item            - the item to look for
@complexity Best = O(1) when the item is the first item in the list
@complexity Worst= O(N) when the item is at the end of the list, where N is the length of the list.
@return     pos     (int)   - an integer representing the position in the list, or False if not found
"""
def find(my_list, item):
    pos = 0
    while pos < len(my_list):
        if my_list[pos] == item:
            return pos
        pos += 1
    return False
#Test function for find(my_list, item)
def test_find():
    list1 = [10, 9, 8, 7]
    item1 = 8
    assert find(list1, item1) == 2
    """
    print(list1)
    print(item1)
    print(find(list1, item1))
    """

    list2 = ['cat', 'dog', 'eagle', 'fox']
    item2 = 'goat'
    """
    print(list2)
    print(item2)
    print(find(list2, item2))
    """
    assert find(list2, item2) == False

    list3 = ['lion', 9, 'yoghurt', False, 'Trex']
    item3 = 'Trex'
    """
    print(list3)
    print(item3)
    print(find(list3, item3))
    """
    assert find(list3, item3) == 4
    print("Tests for find(my_list, item) all passed")

if __name__ == "__main__":
    test_find()

