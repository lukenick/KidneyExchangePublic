__author__ = 'Luke'
__author__ = 'Luke'

import reader
from advanced_matching_solution  import AdvancedMatchingSolution, convert_to_AdvancedMatchingSolution
import advanced_swapper
import time

"""
Tests Heuristic h1 on a given population
"""
def experiment_three(name_array, instances, output=False, paces=1):
    results_array = []
    for name in name_array:
        this_names_row = []
        for n in (instances):
            print("Calculating for " + name + "_i" + (str)(n))
            this_populations_row = [0]*32


            pop_txt = name + "_i" + (str)(n) + ".txt"
            pop_csv = name + "_i" + (str)(n) + ".csv"
            sol_csv = name + "_i" + (str)(n) + "_results.csv"
            firstSolution = convert_to_AdvancedMatchingSolution(reader.create_from_parts(pop_csv, pop_txt, sol_csv))

            this_populations_row[0] = firstSolution.edge_weight
            this_populations_row[1] = firstSolution.node_weight

            for j in range(0, 5):
                time1 = time.clock()
                secondSolution = advanced_swapper.advanced_random_ascent(firstSolution, 5000, ["NODES"], output)
                time2 = time.clock()

                this_populations_row[2 + j*6] = (str)(time2 - time1)
                this_populations_row[3 + j*6] = secondSolution.edge_weight
                this_populations_row[4 + j*6] = secondSolution.node_weight

                time3 = time.clock()
                thirdSolution = advanced_swapper.advanced_random_ascent(secondSolution, 50000, ["NODES", "EDGES"], output, 2)
                time4 = time.clock()

                this_populations_row[5 + j*6] = (str)(time4 - time3)
                this_populations_row[6 + j*6] = thirdSolution.edge_weight
                this_populations_row[7 + j*6] = thirdSolution.node_weight




            print(this_populations_row)
            this_names_row.append(this_populations_row)
        results_array.append(this_names_row)
    return results_array

def write_experiment_one_to_csv(filename, results_array, name_array):
    filename += ".csv"
    myFile = open(filename, 'w')
    name = 0
    for this_names_row in results_array:
        print("Writing for " + name_array[name])
        #Write the name of this population
        my_string = name_array[name] + "\n"
        myFile.write(my_string)

        #Write the column labels
        my_string = ""
        for p in range(0, len(this_names_row)):
            my_string += ",i" + (str)(p) + ",,,,,"
        my_string += "\n"
        myFile.write(my_string)

        #Write the initial solution row
        my_string = "initialSol"
        for x in range(0, len(this_names_row)):
            my_string += ",-," + (str) (this_names_row[x][0]) + "," + (str) (this_names_row[x][1]) + ",,,"
        my_string += "\n"
        myFile.write(my_string)

        #Write the rest of the rows
        rows = len(this_names_row[0])//6
        for r in range(1, rows+1):
            my_string = "r" + (str)(r)
            for x in range(0, len(this_names_row)):
                my_string += "," + (str)(this_names_row[x][r*6-4]) + "," + (str)(this_names_row[x][r*6-3])
                my_string += "," + (str)(this_names_row[x][r*6-2]) + "," + (str)(this_names_row[x][r*6-1])
                my_string += "," + (str)(this_names_row[x][r*6-0]) + "," + (str)(this_names_row[x][r*6+1])
            my_string += "\n"
            myFile.write(my_string)
        name += 1

if __name__ == "__main__":

    name_array = ["InputFiles/AUS_0_200_0/AUS_0_200_0"]
    instances = [3]
    results_array = experiment_three(name_array, instances, True)
    write_experiment_one_to_csv("Advanced_Output_AUS_0_200_0", results_array, name_array)

    name_array = ["InputFiles/AUS_10_190_0/AUS_10_190_0"]
    instances = [3]
    results_array = experiment_three(name_array, instances, False)
    write_experiment_one_to_csv("Advanced_Output_AUS_10_190_0", results_array, name_array)