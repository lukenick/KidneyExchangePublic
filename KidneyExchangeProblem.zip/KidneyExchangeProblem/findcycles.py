__author__ = 'Luke'
"""
Kidney Exchange Problem Generator
Cycle Finding
@since      2/11/2014
@modified   12/11/2014
@author     Luke Nickholds
Built from specifications by Vicky Mak-Hau
"""

"""
def find_cycles(matrix, K):
Finds cycles in a given graph with a length less than k

@param      matrix          - a 2D matrix representing a graph. Cells greater than zero denote a link
@param      K               - cardinality size (the max length of a cycle), a number between 2 and the size of matrix
@complexity worst case is O(N^(K+1)) where N is the amount of vertices and K is the max cycle size
"""
def find_cycles(matrix, K):
    cycles_found = []
    for i in range(0, len(matrix)):     # For each node, find all cycles starting at that node using aux
        cycles_found = cycles_found + aux_find_cycles(matrix, K, K, i, i, [])
    return cycles_found
"""
def aux_find_cycles(matrix, start_k, k_left, first_node, current_node, cycle_list):
Auxilary Function for def find_cycles(matrix, K):
@param      matrix          - a 2D matrix representing the graph
@param      start_k         - the maximum length of a cycle
@param      k_left          - the length of the attempted cycle so far
@param      first_node      - the node that this attempted cycle started at
@param      current_node    - the node currently being looked at
@param      cycle_list      - a list of nodes visited so far in this attempted cycle
"""
def aux_find_cycles(matrix, start_k, k_left, first_node, current_node, cycle_list):
    cycles_found = []
    if start_k != k_left:               # If we haven't just started
        if current_node == first_node:  # and if we are back to the first node
            return [cycle_list]         # return the path we took to get here
    if k_left == 0:
        return []                       # If we've reached max length and it isn't a cycle, return nothing
    row = matrix[current_node]
    for i in range(0, len(row)):
        if row[i] != 0:                 # Try to find cycles from all nodes that this node has paths to
            cycles_found = cycles_found + aux_find_cycles(matrix, start_k, k_left - 1, first_node, i, (cycle_list + [current_node]))
    return cycles_found

#Checks that find_cycles is working on two sets of data
def test_find_cycles():
    luke_matrix = [ [0, 0, 1, 0, 0, 0],
                    [1, 0, 0, 1, 1, 0],
                    [1, 1, 0, 0, 0, 1],
                    [0, 0, 0, 0, 1, 0],
                    [0, 0, 0, 0, 0, 0],
                    [0, 0, 1, 0, 0, 0] ]
    vicky_matrix= [ [0, 0, 3, 0, 0, 0, 0, 1, 0, 5],
                    [2, 0, 0, 0, 0, 0, 1, 0, 1, 2],
                    [0, 1, 0, 1, 1, 0, 1, 0, 0, 1],
                    [1, 1, 0, 0, 1, 0, 1, 1, 0, 5],
                    [0, 1, 1, 1, 0, 4, 5, 1, 1, 2],
                    [3, 0, 0, 0, 0, 0, 0, 1, 0, 3],
                    [1, 0, 0, 2, 0, 1, 0, 0, 0, 4],
                    [1, 0, 0, 0, 0, 0, 0, 0, 1, 1],
                    [0, 0, 1, 0, 3, 0, 1, 0, 0, 4],
                    [0, 0, 0, 0, 0, 1, 0, 0, 0, 0] ]
    luke_cycles = find_cycles(luke_matrix, 3)
    vicky_cycles = find_cycles(vicky_matrix, 3)
    print("Cycles found in Luke's Graph")
    print(luke_cycles)
    print("Cycles found in Vicky's Graph")
    print(vicky_cycles)


"""
def count_cycles(cycle_list, k):
Counts the amount of unique cycles in a given list

@param      cycle_list      - a list of cycle lists to be counted
@param      k               - the max cycle size (including this makes instantiating length_list easier)
@complexity O(N) where N is the length of cycle_list
"""
def count_cycles(cycle_list, k):
    length_list = [0] * (k+1)
    for i in cycle_list:
        if len(i) > 0:
            length_list[len(i)] += 1        # Increment element of length_list that corresponds to length of current cycle
    result = 0
    for j in range(1, len(length_list)):
        result = result + length_list[j]/j
    return result

#Checks that count_cycles is working
def test_count_cycles():
    luke_matrix = [ [0, 0, 1, 0, 0, 0],
                    [1, 0, 0, 1, 1, 0],
                    [1, 1, 0, 0, 0, 1],
                    [0, 0, 0, 0, 1, 0],
                    [0, 0, 0, 0, 0, 0],
                    [0, 0, 1, 0, 0, 0] ]
    vicky_matrix= [ [0, 0, 3, 0, 0, 0, 0, 1, 0, 5],
                    [2, 0, 0, 0, 0, 0, 1, 0, 1, 2],
                    [0, 1, 0, 1, 1, 0, 1, 0, 0, 1],
                    [1, 1, 0, 0, 1, 0, 1, 1, 0, 5],
                    [0, 1, 1, 1, 0, 4, 5, 1, 1, 2],
                    [3, 0, 0, 0, 0, 0, 0, 1, 0, 3],
                    [1, 0, 0, 2, 0, 1, 0, 0, 0, 4],
                    [1, 0, 0, 0, 0, 0, 0, 0, 1, 1],
                    [0, 0, 1, 0, 3, 0, 1, 0, 0, 4],
                    [0, 0, 0, 0, 0, 1, 0, 0, 0, 0] ]
    luke_cycles = find_cycles(luke_matrix, 3)
    vicky_cycles = find_cycles(vicky_matrix, 3)
    print("Cycles found in Luke's Graph")
    print(luke_cycles)
    print("Number of Unique Cycles Expected = 3")
    luke_count = count_cycles(luke_cycles, 3)
    print("Number of Unique Cycles Found = " + (str) (luke_count))
    print("\n")
    print("Cycles found in Vicky's Graph")
    print(vicky_cycles)
    print("Number of Unique Cycles Expected = 10")
    vicky_count = count_cycles(vicky_cycles, 3)
    print("Number of Unique Cycles Found = " + (str) (vicky_count))



if __name__ == "__main__":
    test_find_cycles()
    print()
    test_count_cycles()
