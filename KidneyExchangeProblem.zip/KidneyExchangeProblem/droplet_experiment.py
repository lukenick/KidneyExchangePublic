__author__ = 'Luke'

import reader
from matching_solution import MatchingSolution
import hillclimbing
import time

"""
Tests Heuristic h1 on a given population
"""
def experiment_one(name_array, instances, output=False, paces=1):
    results_array = []
    for name in name_array:
        this_names_row = []
        for n in range(0, instances):
            print("Calculating for " + name + "_i" + (str)(n))
            this_populations_row = [0]*11


            pop_txt = name + "_i" + (str)(n) + ".txt"
            pop_csv = name + "_i" + (str)(n) + ".csv"
            sol_csv = name + "_i" + (str)(n) + "_results.csv"
            initialSolution = reader.create_from_parts(pop_csv, pop_txt, sol_csv)
            this_populations_row[0] = initialSolution.weight

            for j in range(0, 5):
                time1 = time.clock()
                bestSolution = hillclimbing.hill_climbing(initialSolution, 50000, output, paces)
                time2 = time.clock()

                this_populations_row[1 + j*2] = (str)(time2 - time1)
                this_populations_row[2 + j*2] = bestSolution.weight
            print(this_populations_row)
            this_names_row.append(this_populations_row)
        results_array.append(this_names_row)
    return results_array

# The same as experiment_one except with steepest_ascent rather than random_ascent
def experiment_two(name_array, instances, output=False):
    results_array = []
    for name in name_array:
        this_names_row = []
        for n in range(0, instances):
            print("Calculating for " + name + "_i" + (str)(n))
            this_populations_row = [0]*11


            pop_txt = name + "_i" + (str)(n) + ".txt"
            pop_csv = name + "_i" + (str)(n) + ".csv"
            sol_csv = name + "_i" + (str)(n) + "_results.csv"
            initialSolution = reader.create_from_parts(pop_csv, pop_txt, sol_csv)
            this_populations_row[0] = initialSolution.weight

            for j in range(0, 1):
                time1 = time.clock()
                bestSolution = hillclimbing.steepest_ascent(initialSolution, 5000, output)
                time2 = time.clock()

                this_populations_row[1 + j*2] = (str)(time2 - time1)
                this_populations_row[2 + j*2] = bestSolution.weight
            print(this_populations_row)
            this_names_row.append(this_populations_row)
        results_array.append(this_names_row)
    return results_array

def write_experiment_one_to_csv(filename, results_array, name_array):
    filename += ".csv"
    myFile = open(filename, 'w')
    name = 0
    for this_names_row in results_array:
        print("Writing for " + name_array[name])
        #Write the name of this population
        my_string = name_array[name] + "\n"
        myFile.write(my_string)

        #Write the column labels
        my_string = ""
        for p in range(0, len(this_names_row)):
            my_string += ",i" + (str)(p) + ","
        my_string += "\n"
        myFile.write(my_string)

        #Write the initial solution row
        my_string = "initialSol"
        for x in range(0, len(this_names_row)):
            my_string += ",-," + (str) (this_names_row[x][0])
        my_string += "\n"
        myFile.write(my_string)

        #Write the rest of the rows
        rows = len(this_names_row[0])//2
        for r in range(1, rows+1):
            my_string = "r" + (str)(r)
            for x in range(0, len(this_names_row)):
                my_string += "," + (str)(this_names_row[x][r*2-1]) + "," + (str)(this_names_row[x][r*2])
            my_string += "\n"
            myFile.write(my_string)
        name += 1

if __name__ == "__main__":

    name_array = ["InputFiles/AUS_0_200_0/AUS_0_200_0"]
    instances = 1
    results_array = experiment_two(name_array, instances, False)
    write_experiment_one_to_csv("output_two_0_200", results_array, name_array)
    """
    name_array = ["InputFiles/AUS_10_190_0/AUS_10_190_0"]
    instances = 30
    results_array = experiment_two(name_array, instances, False)
    write_experiment_one_to_csv("output_two_10_190", results_array, name_array)
    """
    """
    name_array = ["InputFiles/AUS_0_200_0/AUS_0_200_0"]
    instances = 1
    results_array = experiment_one(name_array, instances, False)
    write_experiment_one_to_csv("output_one_0_200", results_array, name_array)

    name_array = ["InputFiles/AUS_10_190_0/AUS_10_190_0"]
    instances = 30
    results_array = experiment_one(name_array, instances, False)
    write_experiment_one_to_csv("output_one_10_190", results_array, name_array)
    """
