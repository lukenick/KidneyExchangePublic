__author__ = 'Luke'
"""
Kidney Exchange Problem Generator Part One
@since      2/11/2014
@modified   30/05/2015
@author     Luke Nickholds
Built from specifications by Vicky Mak-Hau

"""
import basicgenerator
import clinicalgenerator
import printer
import writer
import autogenerator


"""
Menu Option One: Standard Generator
The user enters the parameters necessary for the standard generator
@return         A KEP graph from basic_generate_graph
"""
def menu_one():
    NbNodes = input("Please enter the number of nodes (int): ")
    k = input("Please enter the value of k (int): ")
    GraphDen = input("Please enter the graph density (0 to 1): ")
    CostType = input("Please enter the cost type (0 or 1): ")
    if CostType == "1":
        MaxArcCost = input("Please enter the MaxArcCost (int): ")
    elif CostType == "0":
        MaxArcCost = 10
    try:
        my_graph = basicgenerator.basic_generate_graph((int)(NbNodes), (float)(GraphDen), (int)(CostType), (int)(MaxArcCost))
    except:
        print("That is not a valid set of inputs")
    return my_graph

"""
Menu Option Two: Clinical Data Generator
The user enters the parameters necessary for clinical_generate_graph1
@return         A KEP graph from clinical_generate_graph1
"""
def menu_two():
    NbNodes = input("Please enter the number of nodes (int): ")
    k = input("Please enter the value of k (int): ")
    MaxArcCost = 1
    try:
        my_graph = clinicalgenerator.clinical_generate_graph1( (int) (NbNodes))
    except:
        print("NbNodes must be an integer")
    return my_graph

"""
The user enters the parameters necessary for clinical_autogenerate1, and the relevant files are made
"""
def menu_six():
    NbNodes = input("Please enter the number of nodes (int): ")
    k = input("Please enter the value of k (int): ")
    g = input("Please enter the amount of instances to create (int)")
    filename = input("Please enter the base name of your files:")
    MaxArcCost = 1
    try:
        NbNodes = (int) (NbNodes)
        k = (int) (k)
        g = (int) (g)
        autogenerator.clinical_autogenerate1(NbNodes, k, g, filename)
    except:
        print("NbNodes must be an integer")

"""
The user enters the parameters necessary for clinical_autogenerate2, and the relevant files are made
"""
def menu_seven():
    NbNodes = input("Please enter the number of nodes (int): ")
    k = input("Please enter the value of k (int): ")
    g = input("Please enter the amount of instances to create (int)")
    filename = input("Please enter the base name of your files:")
    MaxArcCost = 1
    try:
        NbNodes = (int) (NbNodes)
        k = (int) (k)
        g = (int) (g)
        autogenerator.clinical_autogenerate2(NbNodes, k, g, filename)
    except:
        print("NbNodes must be an integer")

"""
The user enters the parameters necessary for complete_autogenerate
"""
def menu_eight():
    NbAltruists = input("Please enter the number of altruist nodes (int): ")
    NbPairs = input("Please enter the number of paired nodes (int)")
    k = input("Please enter the value of k (int): ")
    g = input("Please enter the amount of instances to create (int)")
    filename = "OutputFiles/" + input("Please enter the base name of your files:")
    MaxArcCost = 1
    try:
        NbAltruists = (int) (NbAltruists)
        NbPairs = (int) (NbPairs)
        k = (int) (k)
        g = (int) (g)
        autogenerator.complete_autogenerate(NbAltruists, NbPairs, k, g, filename)
    except ValueError:
        print("NbNodes must be an integer")

if __name__ == "__main__":
    flag = True
    k = 2
    while flag:
        print("Kidney Exchange Problem Generator")
        print("1    = Standard Generator")
        print("2    = Clinical Data Generator")
        print("3    = Print Current Graph")
        print("4    = Output to Data File")
        print("5    = Output to .csv File")
        print("6    = Clinical 1 Autogenerator")
        print("7    = Clinical 2 Autogenerator")
        print("8    = Complete Autogenerator")
        print("0    = Quit")
        response = input("Please enter your selection: ")
        if response == "0":     # Quit
            flag = False

        elif response == "1":   # Basic Graph Generator
            my_graph = menu_one()

        elif response == "2":   # Clinical Graph Generator
            my_graph = menu_two()

        elif response == "3":   # Print Current Graph
            printer.print_matrix(my_graph)

        elif response == "4":   # Output to .txt data file
            filename = input("Please enter the name of your file:")
            writer.output_to_txt1(filename, my_graph)

        elif response == "5":   # Output to .csv file
            filename = input("Please enter the name of your file:")
            writer.output_to_csv1(filename, my_graph)

        elif response == "6":   # Clinical 1 Autogenerator
            menu_six()

        elif response == "7":   # Clinical 2 Autogenerator
            menu_seven()

        elif response == "8":   # Complete Autogenerator
            menu_eight()

        else:
            print("That is not valid response, please try again")

