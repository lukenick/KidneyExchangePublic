__author__ = 'Luke'
class AdvancedMatchingSolution:
    """
    @param      compatability [][]  - a 2D matrix showing the compatibility of each pair to another
    @param      edge_matrix [][]    - a 2D matrix showing the desirability of edges between each pair and another
    @param      node_matrix []      - a 1D matrix showing the desirability of each node
    @param      pairing [][]        - a list of lists. Each inner list contains a cycle or chain of nodes
    """
    def __init__(self, compatability, edge_matrix, node_matrix, pairing):
        self.compatibility = compatability
        self.edge_matrix = edge_matrix
        self.node_matrix = node_matrix
        self.solution = pairing
        self.nodes = len(compatability)

        e_weight = 0
        n_weight = 0
        for cycle in pairing:
            i = 1                   # The first item in each cycle is "Chain" or "Cycle"
            j = len(cycle)
            n_weight += self.node_matrix[cycle[1]]
            while i < j-1:
                node1 = cycle[i]
                node2 = cycle[i+1]
                e_weight += self.edge_matrix[node1][node2]
                n_weight += self.node_matrix[node2]
                i += 1
            #If a cycle, need to look at the last link - between final node in cycle and first
            if cycle[0] == "Cycle":
                node1 = cycle[i]
                node2 = cycle[1]
                e_weight += self.edge_matrix[node1][node2]


            i += 1
        self.edge_weight = e_weight
        self.node_weight = n_weight

#   This needs to be cleaned up
#   you need to make sure that you have got your weights going the right way around
#
#
#


"""
def convert_to_AdvancedMatchingSolution(myMatchingSolution):

Takes as input a MatchingSolution object and converts it to an AdvancedMatchingSolution object
@param      myMatchingSolution (MatchingSolution)   - a MatchingSolution object to be converted
@return     an AdvancedMatchingSolution object      - note: node weights = (node_num % 5) + 1
"""
def convert_to_AdvancedMatchingSolution(myMatchingSolution):
    node_matrix = []
    for i in range(len(myMatchingSolution.compatibility[0])):
        node_matrix.append(i%5 + 1)
    print(node_matrix)
    return AdvancedMatchingSolution(myMatchingSolution.compatibility, myMatchingSolution.edge_weights, node_matrix, myMatchingSolution.solution)

def testing_one():
    import population_library

    compatibility1 = population_library.basic_graph01
    edge_weights1 = population_library.basic_edges01
    node_weights1 = population_library.basic_nodes01
    solution1 = [ ["Cycle", 0, 4, 1], ["Cycle", 2, 3]]

    testSolution = AdvancedMatchingSolution(compatibility1, edge_weights1, node_weights1, solution1)

    assert testSolution.edge_weight == 28
    assert testSolution.node_weight == 15
    print("Test One Passed: (__init__ and edge/node weight)")

def testing_two():
    import population_library

    compatibility2 = population_library.basic_graph02
    edge_weights2 = population_library.basic_edges02
    node_weights2 = population_library.basic_nodes02
    solution2 = [ ["Cycle", 0, 4, 1], ["Cycle", 2, 7, 3]]
    testSolution = AdvancedMatchingSolution(compatibility2, edge_weights2, node_weights2, solution2)

    assert testSolution.edge_weight == 44
    assert testSolution.node_weight == 19
    print("Test Two Passed: (__init__ and edge/node weight)")


if __name__ == "__main__":
    testing_one()
    testing_two()
