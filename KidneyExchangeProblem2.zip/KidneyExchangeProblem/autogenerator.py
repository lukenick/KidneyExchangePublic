__author__ = 'Luke'
"""
Kidney Exchange Problem Autogenerators
@since      30/03/2015
@modified   30/03/2015
@author     Luke Nickholds
Methods for automatically generating multiple files representing populations with similiar characteristics
"""

import clinicalgenerator
import altruisticgenerator
import writer

"""
def clinical_autogenerate1(my_graph, NbNodes, k, g, filename):
Automatically generates multiple related populations using clinical_generate_graph1
and writes to seperate files (both txt and csv)

@param      NbNodes (int)   - the number of nodes to generate per graph
@param      k (int)         - the value of k ### currently not used
@param      g (int)         - the amount of populations to generate
@param      filename (str)  - the basic form of the fileame to be used (sample is filename_i4.)
@complexity O(G*N^2) where G is the amount of populations and N is the number of nodes in each
"""
def clinical_autogenerate1(NbNodes, k, g, filename):
    for x in range(0, g):
        my_graph = clinicalgenerator.clinical_generate_graph1( (int) (NbNodes))
        txt_name = filename + "_i" + (str)(x) + ".txt"  #Sample name: filename_i4.txt
        csv_name = filename + "_i" + (str)(x) + ".csv"  #Sample name: filename_i4.csv
        writer.output_to_txt1(txt_name, my_graph)
        writer.output_to_csv1(csv_name, my_graph)


"""
def clinical_autogenerate2(my_graph, NbNodes, k, g, filename):
Automatically generates multiple related populations using clinical_generate_graph2
and writes to seperate files (both txt and csv)

@param      NbNodes (int)   - the number of nodes to generate per graph
@param      k (int)         - the value of k ### currently not used
@param      g (int)         - the amount of populations to generate
@param      filename (str)  - the basic form of the fileame to be used (sample is filename_i4.)
@complexity O(G*N^2) where G is the amount of populations and N is the number of nodes in each
"""
def clinical_autogenerate2(NbNodes, k, g, filename):
    for x in range(0, g):
        my_graph = clinicalgenerator.clinical_generate_graph1( (int) (NbNodes))
        txt_name = filename + "_i" + (str)(x) + ".txt"  #Sample name: filename_i4.txt
        csv_name = filename + "_i" + (str)(x) + ".csv"  #Sample name: filename_i4.csv
        writer.output_to_txt1(txt_name, my_graph)
        writer.output_to_csv1(csv_name, my_graph)

"""
def complete_autogenerate_node1(NbAltruists, NbPairs, NbTerminal, minweight=1, maxweight=100, k ,g, filename):
Automatically generates multiple related populations using complete_generate_node1
and writes to seperate files (both txt and csv) *** CURRENTLY ONLY TO CSV ***

@param      NbNodes (int)   - the number of nodes to generate per graph
@param      k (int)         - the value of k ### currently not used
@param      g (int)         - the amount of populations to generate
@param      filename (str)  - the basic form of the fileame to be used (sample is filename_i4.)
@complexity O(G*N^2) where G is the amount of populations and N is the number of nodes in each
"""
def complete_autogenerate(NbAltruists, NbPairs, k ,g, filename, minweight=1, maxweight=100,):
    for x in range(0, g):
        my_graph = altruisticgenerator.altruistic_generate_graph2(NbAltruists, NbPairs, False, 100)
        txt_name = filename + "_i" + (str)(x) + ".txt"  #Sample name: filename_i4.txt
        csv_name = filename + "_i" + (str)(x) + ".csv"  #Sample name: filename_i4.csv
        writer.output_to_txt2(txt_name, my_graph, NbAltruists, NbPairs, NbAltruists)
        writer.output_to_csv2(csv_name, my_graph, NbAltruists, NbPairs, NbAltruists)

if __name__ == "__main__":
    #clinical_autogenerate1(10, 2, 3, "this_file_name1")
    #clinical_autogenerate2(10, 3, 2, "this_file_name2")
    complete_autogenerate(4, 2, 3, 2, "this_file_name3")
    pass
