__author__ = 'Luke'
from advanced_matching_solution import AdvancedMatchingSolution,convert_to_AdvancedMatchingSolution
from misc_functions import find
import random
import math
import printer
import population_library
import reader

"""
def advanced_smarter_swap(initial_solution):

Takes an initial solution and tries to perform a random swap between two nods to find a new feasible solution. The new
feasible solution will not necessarily be more desirable. Will not swap first or last node in a chain.
@param      intital_solution  (AdvancedMatchingSolution) - an instance of a AdvancedMatchingSolution object, representing a feasible solution
"""
def advanced_smarter_swap(initial_solution):
    count1 = 0
    while count1 < 1000:           # This is to ensure that if there is only one feasible solution we don't loop forever
        r = math.floor( random.random()*len(initial_solution.solution))     # Pick a random number for cycle1
        cycle1 = initial_solution.solution[r][1:]           # ie [4, 7, 5]
        cycle1_type = initial_solution.solution[r][0]       # "Chain" or "Cycle"
        r = math.floor( random.random()*(len(cycle1)) )     # Pick a random num for a node
        swap_node1 = cycle1[r]
        # So we've now picked our first random node


        count2 = 0
        if cycle1_type == "Chain" and (r==0 or r==len(cycle1)):
            count2 = 99999999       # If we pick the first or last element in a chain, pick again
        while count2 < 1000:
            # Pick second node
            swap_node2 = math.floor( random.random() * initial_solution.nodes )
            # Now we need to find if this is in a cycle/chain already
            both_in_cycle = False
            for x in initial_solution.solution:
                if swap_node2 in x:
                    both_in_cycle = True
                    cycle2 = x[1:]          # The first element is the type "Chain" or "Cycle"
                    cycle2_type = x[0]      # ie [8, 3, 2]

            if both_in_cycle:            # If it's in a cycle, our work is harder
                if cycle2_type == "Chain" and (cycle2[0]==swap_node2 or cycle2[-1]==swap_node2):
                    pass                # If in a chain, and first or last node, just pick a new second node
                else:                   # Else, lets see if a swap is feasible
                    pos1 = find(cycle1, swap_node1)
                    A = cycle1[ (pos1-1)%len(cycle1) ]
                    B = swap_node1
                    C = cycle1[ (pos1+1)%len(cycle1) ]

                    pos2 = find(cycle2, swap_node2)
                    D = cycle2[ (pos2-1)%len(cycle2)]
                    E = swap_node2
                    F = cycle2[ (pos2+1)%len(cycle2)]

                    can_swap = True
                    for pair in [ [A, E], [E, C], [D, B], [B, F] ]:     # These are the four new edges that would be used if a swap occurs
                        if initial_solution.compatibility[pair[0]][pair[1]] <= 0:
                            can_swap = False

                    # If we can swap, and the aren't the same node - construct and return the new solution!
                    if can_swap and (swap_node1 != swap_node2):
                        new_cycle1 = cycle1[:]      # Clone list
                        new_cycle1.insert(0, cycle1_type)
                        new_cycle1[find(new_cycle1, swap_node1)] = swap_node2
                        new_cycle2 = cycle2[:]      # Clone list
                        new_cycle2.insert(0, cycle2_type)
                        new_cycle2[find(new_cycle2, swap_node2)] = swap_node1

                        new_pairing = initial_solution.solution[:]
                        new_pairing[find(new_pairing, [cycle1_type] + cycle1)] = new_cycle1     #This is more complicated because cycle1 is in the format [156, 61, 157]
                        new_pairing[find(new_pairing, [cycle2_type] + cycle2)] = new_cycle2     #but new pairing contains things in the form ["Cycle", 156, 61, 157]
                        newSolution = AdvancedMatchingSolution(initial_solution.compatibility, initial_solution.edge_matrix, initial_solution.node_matrix, new_pairing)
                        return newSolution
            else:           # If swap_node2 is a loose node
                pos1 = find(cycle1, swap_node1)
                A = cycle1[ (pos1-1)%len(cycle1) ]
                B = swap_node1
                C = cycle1[ (pos1+1)%len(cycle1) ]
                E = swap_node2

                can_swap = True
                for pair in [ [A, E], [E, C]]:
                    if initial_solution.compatibility[pair[0]][pair[1]] <=0:
                        can_swap = False
                # If can swap and both nodes aren't the same, construct and return the new solution
                if can_swap and (swap_node1 != swap_node2):
                    new_cycle1 = cycle1[:]      # Clone list
                    new_cycle1.insert(0, cycle1_type)
                    new_cycle1[find(new_cycle1, swap_node1)] = swap_node2

                    new_pairing = initial_solution.solution[:]
                    new_pairing[find(initial_solution.solution, [cycle1_type] + cycle1)] = new_cycle1
                    newSolution = AdvancedMatchingSolution(initial_solution.compatibility, initial_solution.edge_matrix, initial_solution.node_matrix, new_pairing)
                    return newSolution

            count2 += 1 #If we didn't find a valid swap, try a new second node
        # After 1000 attempts with this particular node as swap_node1, give up and try a new node 1
        count1 += 1

    # If after 1000 swap_node1s we haven't found a valid solution, give up and return False
    return False


"""
def advanced_random_ascent(initial_solution, iterations, criteria, output=False):

Implements the hill-climbing algorithm using a RANDOM ascent, using smarter_swap to generate new solutions.
@param      initial_solution (AdvancedMatchingSolution) - an initial, feasible solution
@param      iterations (int)                        - the number of new solutions to generate
@param      criteria [str]                          - a list of strings representing the criteria to check against
                                                    all criteria listed must be maintained or improved
@param      output (bool)                           - set to True to print both weights each iteration. Default=False
@param      advancedData (bool)                     - set to True to return the best solution as well as swaps performed and best iteration. Default=False
@param      paces (int)                             - how many times to run smarter_swap to generate new sol. Default=1
@complexity O(MN) where N is the amount of iterations, and O(N) is the complexity of smarter_swap
"""
def advanced_random_ascent(initial_solution, iterations, criteria, output=False, advancedData=False, paces=1):
    best_solution = initial_solution
    swaps = 0       # Keep track of how many swaps have been accepted
    best_i = -1     # Keep track of which iteration last had a switch occur
    for i in range(iterations):
        new_solution = best_solution
        for _ in range(paces):
            new_solution =  advanced_smarter_swap(new_solution)
        worse = False
        better = False
        if "EDGES" in criteria:
            if (output):
                print("Iteration: " + (str)(i))
                print("New Solution Edge Weight = " + (str) (new_solution.edge_weight))
                print("Best Solution Edge Weight = " + (str) (best_solution.edge_weight))
            if (new_solution.edge_weight < best_solution.edge_weight):
                worse = True
            elif (new_solution.edge_weight > best_solution.edge_weight):
                better = True

        if "NODES" in criteria:
            if (output):
                print("Iteration: " + (str)(i))
                print("New Solution Node Weight = " + (str) (new_solution.node_weight))
                print("Best Solution Node Weight = " + (str) (best_solution.node_weight))
            if (new_solution.node_weight < best_solution.node_weight):
               worse = True
            elif (new_solution.edge_weight > best_solution.edge_weight):
                better = True
        if (not worse) and (better):
            best_solution = new_solution
            swaps += 1
            best_i = i



    if True: #output:      # If output, display at the end when the last iteration with a switch was
        print("Best Solution Edge Weight = " + (str) (best_solution.edge_weight))
        print("Best Solution Node Weight = " + (str) (best_solution.node_weight))
        print("Best Solution was found during iteration " + (str) (best_i))

    if advancedData:
        return [best_solution, swaps, best_i]
    else:
        return best_solution

# Testing for advanced_random_ascent
def test_advanced_random_ascent():
    comp = population_library.basic_graph02
    edges = population_library.basic_edges02
    nodes = population_library.basic_nodes02
    initial_solution = AdvancedMatchingSolution(comp, edges, nodes, [["Cycle", 0, 4, 1], ["Cycle", 2, 6, 3]])
    best_solution = advanced_random_ascent(initial_solution, 2000, ["EDGES"])
    print()
    best_solution = advanced_random_ascent(initial_solution, 2000, ["NODES, EDGES"])
    print()
    best_solution = advanced_random_ascent(initial_solution, 2000, ["EDGES, NODES"])
    print()

# Simple Testing for Advanced Smarter Swap
def test5():
    comptability5 = population_library.basic_graph02
    edge_matrix5 = population_library.basic_edges02
    node_matrix5 = population_library.basic_nodes02

    solution5 = [ ["Cycle", 0, 4, 1], ["Cycle", 2, 6, 3]]
    testSolution5 = AdvancedMatchingSolution(comptability5, edge_matrix5, node_matrix5, solution5)
    newSolution = advanced_smarter_swap(testSolution5)
    print(testSolution5.solution)
    print(newSolution.solution)

def big_old_test():
    result = reader.create_from_parts("InputFiles/AUS_0_200_0/AUS_0_200_0_i0.csv", "InputFiles/AUS_0_200_0/AUS_0_200_0_i0.txt", "InputFiles/AUS_0_200_0/AUS_0_200_0_i0_results.csv")
    aSolution = convert_to_AdvancedMatchingSolution(result)
    bestSolution = advanced_random_ascent(aSolution, 2000, ["EDGES"], True)
    print("YOLO")
    advanced_random_ascent(bestSolution, 2000, ["NODES", "EDGES"], True)

if __name__ == "__main__":
    big_old_test()
    #test_advanced_random_ascent()
