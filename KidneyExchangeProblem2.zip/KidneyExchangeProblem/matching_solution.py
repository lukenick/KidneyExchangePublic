__author__ = 'Luke'
class MatchingSolution:
    """
    @param      compatability [][]  - a 2D matrix showing the compatibility of each pair to another
    @param      edge_weights [][]   - a 2D matrix showing the desirability of edges between each pair and another
    @param      pairing [][]        - a list of lists. Each inner list contains a cycle or chain of nodes
    """
    def __init__(self, compatibility, edge_weights, pairing):
        self.compatibility = compatibility
        self.edge_weights = edge_weights
        self.solution = pairing
        self.nodes = len(compatibility)

        weight = 0
        for cycle in pairing:
            i = 1                   # The first item in each cycle is "Chain" or "Cycle"
            j = len(cycle)
            while i < j-1:
                node1 = cycle[i]
                node2 = cycle[i+1]
                weight += self.edge_weights[node1][node2]
                i += 1
            #If a cycle, need to look at the last link - between final node in cycle and first
            if cycle[0] == "Cycle":
                node1 = cycle[i]
                node2 = cycle[1]
                weight += self.edge_weights[node1][node2]


            i += 1
        self.weight = weight

#   This needs to be cleaned up
#   you need to make sure that you have got your weights going the right way around
#
#
#
def testing_one():
    compatibility1 = [[-9999,     1, -9999, -9999, -9999, -9999],
                      [    1, -9999, -9999, -9999, -9999, -9999],
                      [-9999, -9999, -9999, -9999,     1,     1],
                      [-9999, -9999, -9999, -9999, -9999, -9999],
                      [-9999, -9999,     1, -9999, -9999,     1],
                      [-9999, -9999,     1, -9999,     1, -9999],]

    weights1       = [[    0,     6,     0,     0,     0,     0],
                      [    5,     1,     0,     0,     0,     0],
                      [    0,     1,     0,     0,    40,    12],
                      [    0,     1,     0,     0,     0,     0],
                      [    0,     1,    10,     0,     0,     90],
                      [    0,     1,    90,     0,    11,     0],]
    solution1 = [ ["Cycle", 0, 1], ["Cycle", 2, 4, 5] ]

    testSolution = MatchingSolution(compatibility1, weights1, solution1)
    assert testSolution.weight == (6 + 5 + 40 + 90 + 90)
    print("Test One Passed")





if __name__ == "__main__":
    testing_one()
