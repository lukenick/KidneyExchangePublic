__author__ = 'Luke'
__author__ = 'Luke'

import reader
from advanced_matching_solution  import AdvancedMatchingSolution, convert_to_AdvancedMatchingSolution
import advanced_swapper
import time

"""
Tests Heuristic h1 on a given population
"""
def experiment_three(name_array, instances, XN_iterations, XNE_iterations, output=False):
    results_array = []
    for name in name_array:
        this_names_row = []
        for n in (instances):
            print("Calculating for " + name + "_i" + (str)(n))
            this_populations_row = [0]*(2 + 5*10)       # 2 Elements for N0 E0, then 5 rows of 10


            pop_txt = name + "_i" + (str)(n) + ".txt"
            pop_csv = name + "_i" + (str)(n) + ".csv"
            sol_csv = name + "_i" + (str)(n) + "_results.csv"
            firstSolution = convert_to_AdvancedMatchingSolution(reader.create_from_parts(pop_csv, pop_txt, sol_csv))

            this_populations_row[0] = firstSolution.edge_weight
            this_populations_row[1] = firstSolution.node_weight

            for j in range(0, 5):
                time1 = time.clock()
                result = advanced_swapper.advanced_random_ascent(firstSolution, XN_iterations, ["NODES"], output, True, 1)
                secondSolution = result[0]
                time2 = time.clock()

                this_populations_row[2 + j*10] = (str)(time2 - time1)           # Time Taken
                this_populations_row[3 + j*10] = result[1]                      # Swaps Done
                this_populations_row[4 + j*10] = result[2]                      # Iteration of last swap
                this_populations_row[5 + j*10] = secondSolution.node_weight     # Node Weight
                this_populations_row[6 + j*10] = secondSolution.edge_weight     # Edge Weight

                time3 = time.clock()
                result = advanced_swapper.advanced_random_ascent(secondSolution, XNE_iterations, ["NODES", "EDGES"], output, True, 2)
                thirdSolution = result[0]
                time4 = time.clock()

                this_populations_row[7 + j*10] = (str)(time4 - time3)           # Time Taken
                this_populations_row[8 + j*10] = result[1]                      # Swaps Done
                this_populations_row[9 + j*10] = result[2]                      # Iteration of last swap
                this_populations_row[10 + j*10] = thirdSolution.node_weight     # Node Weight
                this_populations_row[11 + j*10] = thirdSolution.edge_weight     # Edge Weight




            print(this_populations_row)
            this_names_row.append(this_populations_row)
        results_array.append(this_names_row)
    return results_array

def write_experiment_one_to_csv(filename, results_array, name_array):
    filename += ".csv"
    myFile = open(filename, 'w')
    name = 0
    for this_names_row in results_array:
        print("Writing for " + name_array[name])
        #Write the name of this population
        my_string = name_array[name] + "\n"
        myFile.write(my_string)

        #Write the column labels
        my_string = ""
        for p in range(0, len(this_names_row)):
            my_string += ",i" + (str)(p) + ",,,,,"
        my_string += "\n"
        myFile.write(my_string)

        #Write the initial solution row
        my_string = "initialSol"
        for x in range(0, len(this_names_row)):
            my_string += ",-," + (str) (this_names_row[x][0]) + "," + (str) (this_names_row[x][1]) + ",,,"
        my_string += "\n"
        myFile.write(my_string)

        #Write the rest of the rows
        rows = len(this_names_row[0])//10
        for r in range(1, rows+1):
            my_string = "r" + (str)(r)
            for x in range(0, len(this_names_row)):
                my_string += "," + (str)(this_names_row[x][r*10-8]) + "," + (str)(this_names_row[x][r*10-7])
                my_string += "," + (str)(this_names_row[x][r*10-6]) + "," + (str)(this_names_row[x][r*10-5])
                my_string += "," + (str)(this_names_row[x][r*10-4]) + "," + (str)(this_names_row[x][r*10-3])
                my_string += "," + (str)(this_names_row[x][r*10-2]) + "," + (str)(this_names_row[x][r*10-1])
                my_string += "," + (str)(this_names_row[x][r*10+0]) + "," + (str)(this_names_row[x][r*10+1])
            my_string += "\n"
            myFile.write(my_string)
        name += 1

if __name__ == "__main__":
    for p in range(0, 30):
        name_array = ["InputFiles/AUS_0_200_0/AUS_0_200_0"]
        instances = [p]
        results_array = experiment_three(name_array, instances, 500, 5000)
        string1 = "OutputFiles/AdvancedOutput/AUS_200_0_i" + (str)(p)
        write_experiment_one_to_csv(string1, results_array, name_array)

        name_array = ["InputFiles/AUS_10_190_0/AUS_10_190_0"]
        instances = [p]
        results_array = experiment_three(name_array, instances, 500, 5000)
        string2 = "OutputFiles/AdvancedOutput/AUS_10_190_i" + (str)(p)
        write_experiment_one_to_csv(string2, results_array, name_array)