__author__ = 'Luke'
"""
Kidney Exchange Problem Generator
Basic Generator
@since      2/11/2014
@modified   18/06/2015
@author     Luke Nickholds
Built from specifications by Vicky Mak-Hua
"""
import random
import printer
import math

"""
def generate_graph(NbNodes, GraphDen, CostType, MaxArcCost):
Generates a 2D array of size NbNodes by NbNodes that simulates a population under the given specs

@param      NbNodes (int)   - the number of vertices on the graph
@param      GraphDen (float)- density of graph, a number between 0 and 1
@param      CostType (bin)  - if 0 then cost of all valid arcs is 1
                            - if 1 then cost of all valid arcs is random between 1 and MaxArcCost
@param      MaxArcCost (int)- the maximum cost of an arc.           Default = 50
@complexity O(N^2) where N is the size of NbNodes
"""
def basic_generate_graph(NbNodes, GraphDen, CostType, MaxArcCost=50):
    ArcCosts = [[-9999 for i in range(NbNodes)] for i in range(NbNodes)] # Create blank array of -9999
    for i in range(0, NbNodes):
        for j in range(0, NbNodes):
            value = random.random()
            if value < GraphDen and i!=j:    # Chance of valid arc is GraphDen
                if CostType == 0:
                    ArcCosts[i][j] = 1  # all valid arcs are 1
                elif CostType == 1:
                    ArcCosts[i][j] = (int) (1 + math.floor(random.random()*(MaxArcCost))) # all valid arcs are between 1 and MaxArcCost
    return ArcCosts

if __name__ == "__main__":
    print("\nThe first graph is type 0 (all nodes -9999 or 1) and has 5 nodes with ~20% density")
    graph1 = basic_generate_graph(5, .2, 0, 50)
    printer.print_matrix(graph1)

    print("\nThe second graph is type 1 (all nodes -9999 or between 1 and MaxArcCost) and has 10 nodes with ~80% density and MaxArcCost = 50")
    graph2 = basic_generate_graph(10, .8, 1, 50)
    printer.print_matrix(graph2)